﻿using Microsoft.EntityFrameworkCore;
using vendinha_plena.Models;

namespace vendinha_plena.Data
{
    public class AppDbContext: DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)

        {

        }


        public DbSet<Cliente> Produtos { get; set; }

    }
}
