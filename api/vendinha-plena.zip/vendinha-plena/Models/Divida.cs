﻿namespace vendinha_plena.Models
{
    public class Divida
    {
        public int Id { get; set; }

        public string Valor { get; set; }

        public Boolean Situacao { get; set; }

        public DateOnly DataCriacao { get; set; }

        public DateOnly DataPagto { get; set; }
    }
}
