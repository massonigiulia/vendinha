﻿namespace vendinha_plena.Models
{
    public class Cliente
    {
        public int Id { get; set; }

        public string Nome { get; set; }

        public string CPF { get; set; }

        public DateOnly DataNasc { get; set; }

        public string Email { get; set; }
    }
}
